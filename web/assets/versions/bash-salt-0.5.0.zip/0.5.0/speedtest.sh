function speedtest() {
    ~/source/repos/Bash-salt/src/speedtest/speedtest.exe
}