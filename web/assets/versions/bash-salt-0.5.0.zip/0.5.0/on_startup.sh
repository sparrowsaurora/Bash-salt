# Run startup file
~/source/repos/Bash-salt/src/on_startup/on_startup.exe
