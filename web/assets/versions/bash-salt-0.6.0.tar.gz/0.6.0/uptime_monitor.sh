function uptime_monitor() {
    # Run executable
    ~/source/repos/Bash-salt/src/uptime_monitor/uptime_monitor.exe
}